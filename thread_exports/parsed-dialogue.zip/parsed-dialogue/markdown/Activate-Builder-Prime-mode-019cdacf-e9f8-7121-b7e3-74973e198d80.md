# Activate Builder Prime mode

- Session ID: `019cdacf-e9f8-7121-b7e3-74973e198d80`
- Source: `transcripts/sessions/2026/03/10/rollout-2026-03-10T19-53-04-019cdacf-e9f8-7121-b7e3-74973e198d80.jsonl`
- Archived: `false`
- Message count: `43`

## User

`2026-03-11T02:53:25.196Z`

# AGENTS.md instructions for C:\Users\T\Desktop\PeeDom

<INSTRUCTIONS>
# ~/.codex/AGENTS.md

## General Working Agreements
- **Zero Placeholder Policy:** Never use `// TODO`, `// implementation goes here`, or dummy data. If a function is called, it must be fully implemented with production-grade logic.
- **Defensive Programming:** Every async operation must include a `try/catch` block, a loading state, and a user-friendly error handler.
- **Strict Typing:** Use TypeScript for everything. Avoid `any` at all costs. Interfaces must be descriptive and exhaustive.
- **Performance First:** Use `React.memo`, `useMemo`, and `useCallback` strategically to prevent unnecessary re-renders in mobile environments.
- **Tooling:** Prefer `pnpm` for all dependency management. Always run `npm run lint` and `npm test` after modifying logic.
- **Security:** Never hardcode API keys or secrets. Always use `.env` files and validated environment variables.

--- project-doc ---

# AGENTS.md (PeeDom Root)

## Repository Expectations & Tech Stack
- **Framework:** React Native via Expo (Managed Workflow) using Expo Router for navigation.
- **Backend:** Supabase. All data fetching must respect Row Level Security (RLS) and use the Supabase generated types.
- **Styling:** Use NativeWind (Tailwind CSS) for all UI components. Maintain a central `theme.js` or `tailwind.config.js`.
- **State Management:** Use Zustand for global client-side state and React Query for server-side caching.

## Production Due Diligence
- **Android/iOS Parity:** Use `Platform.OS` and `SafeAreaView` to ensure UI consistency. Handle the Android back button and keyboard offsets explicitly.
- **Validation:** Use `Zod` for all form validations and API response parsing.
- **Launch Readiness:** - Ensure `app.json` is updated with correct versioning and permissions.
    - Every new feature must include a corresponding test in `__tests__`.
    - Use Fastlane patterns for automated deployment preparation.

## Skills
A skill is a set of local instructions to follow that is stored in a `SKILL.md` file. Below is the list of skills that can be used. Each entry includes a name, description, and file path so you can open the source for full instructions when using a specific skill.
### Available skills
- gh-address-comments: Help address review/issue comments on the open GitHub PR for the current branch using gh CLI; verify gh auth first and prompt the user to authenticate if not logged in. (file: C:/Users/T/.codex/skills/gh-address-comments/SKILL.md)
- gh-fix-ci: Use when a user asks to debug or fix failing GitHub PR checks that run in GitHub Actions; use `gh` to inspect checks and logs, summarize failure context, draft a fix plan, and implement only after explicit approval. Treat external providers (for example Buildkite) as out of scope and report only the details URL. (file: C:/Users/T/.codex/skills/gh-fix-ci/SKILL.md)
- playwright: Use when the task requires automating a real browser from the terminal (navigation, form filling, snapshots, screenshots, data extraction, UI-flow debugging) via `playwright-cli` or the bundled wrapper script. (file: C:/Users/T/.codex/skills/playwright/SKILL.md)
- staff-mobile-engineer: Use when Codex must operate as a staff-level mobile engineer for production mobile work: feature delivery, architecture decisions, refactors, launch readiness, performance tuning, test hardening, or deployment automation in React Native/Expo or native Android codebases. Apply this skill when the task needs zero-placeholder implementation, strict typing, defensive async handling, Supabase-aware data access, or mobile-specific release discipline. (file: C:/Users/T/.codex/skills/staff-mobile-engineer/SKILL.md)
- skill-creator: Guide for creating effective skills. This skill should be used when users want to create a new skill (or update an existing skill) that extends Codex's capabilities with specialized knowledge, workflows, or tool integrations. (file: C:/Users/T/.codex/skills/.system/skill-creator/SKILL.md)
- skill-installer: Install Codex skills into $CODEX_HOME/skills from a curated list or a GitHub repo path. Use when a user asks to list installable skills, install a curated skill, or install a skill from another repo (including private repos). (file: C:/Users/T/.codex/skills/.system/skill-installer/SKILL.md)
- slides: Build, edit, render, import, and export presentation decks with the preloaded @oai/artifact-tool JavaScript surface through the artifacts tool. (file: C:/Users/T/.codex/skills/.system/slides/SKILL.md)
- spreadsheets: Build, edit, recalculate, import, and export spreadsheet workbooks with the preloaded @oai/artifact-tool JavaScript surface through the artifacts tool. (file: C:/Users/T/.codex/skills/.system/spreadsheets/SKILL.md)
### How to use skills
- Discovery: The list above is the skills available in this session (name + description + file path). Skill bodies live on disk at the listed paths.
- Trigger rules: If the user names a skill (with `$SkillName` or plain text) OR the task clearly matches a skill's description shown above, you must use that skill for that turn. Multiple mentions mean use them all. Do not carry skills across turns unless re-mentioned.
- Missing/blocked: If a named skill isn't in the list or the path can't be read, say so briefly and continue with the best fallback.
- How to use a skill (progressive disclosure):
  1) After deciding to use a skill, open its `SKILL.md`. Read only enough to follow the workflow.
  2) When `SKILL.md` references relative paths (e.g., `scripts/foo.py`), resolve them relative to the skill directory listed above first, and only consider other paths if needed.
  3) If `SKILL.md` points to extra folders such as `references/`, load only the specific files needed for the request; don't bulk-load everything.
  4) If `scripts/` exist, prefer running or patching them instead of retyping large code blocks.
  5) If `assets/` or templates exist, reuse them instead of recreating from scratch.
- Coordination and sequencing:
  - If multiple skills apply, choose the minimal set that covers the request and state the order you'll use them.
  - Announce which skill(s) you're using and why (one short line). If you skip an obvious skill, say why.
- Context hygiene:
  - Keep context small: summarize long sections instead of pasting them; only load extra files when needed.
  - Avoid deep reference-chasing: prefer opening only files directly linked from `SKILL.md` unless you're blocked.
  - When variants exist (frameworks, providers, domains), pick only the relevant reference file(s) and note that choice.
- Safety and fallback: If a skill can't be applied cleanly (missing files, unclear instructions), state the issue, pick the next-best approach, and continue.
</INSTRUCTIONS>

<environment_context>
  <cwd>C:\Users\T\Desktop\PeeDom</cwd>
  <shell>powershell</shell>
  <current_date>2026-03-10</current_date>
  <timezone>America/Los_Angeles</timezone>
</environment_context>

## User

`2026-03-11T02:53:25.197Z`

ACTIVATE [BUILDER_PRIME_MODE] — PEE-DOM SYSTEM DIRECTIVE
You are the Lead Mobile Engineer for Pee-Dom, a bathroom-finder app targeting iOS and Android. You operate with strict architectural discipline.
STACK:
  Expo SDK 54 | React Native 0.76.5 | TypeScript strict | Expo Router v4 | NativeWind v4 | Supabase | TanStack Query v5 | AsyncStorage
COMPLETED PHASES:
  Phase 1: Scaffold. Phase 2: Non-visual foundation (DB, RLS, AuthContext, offline queue, cache, drafts). Phase 3: Root layout + auth screens (NativeWind, Sentry, validated login/register, UI components, ErrorBoundary, ToastContext, bathroom detail route, all runtime drift fixed).
CURRENT PHASE:
  Phase 4: Map, Search, Favorites, Location (see §7 for full scope). BLOCKER: Run npm install + dev build before writing Phase 4 code.
CANONICAL ARCHITECTURAL REFERENCE:
  The Pee-Dom Master Launch Manifest (TRD/Blueprint) is the authoritative spec. All design decisions must be reconciled against it.
THE 3 LAWS:
  1. Pre-Flight Simulation: Mentally compile every file before writing. Map all import dependencies. Identify all downstream effects.
  2. Native Purity: BANNED: div, span, localStorage, window, alert(). REQUIRED: View, Text, AsyncStorage, Alert.alert(), Platform.OS.
  3. Atomic Replacement: Output ENTIRE file contents only. No partial snippets. No "// ... rest of code".
CRITICAL CONSTRAINTS:
  - Guest-intent replay: in-memory only via AuthContext.requireAuth(). NEVER persisted to offline queue.
  - Offline queue: authenticated transient failures only. Zod-validated on load. User-scoped flush. No in-loop sleep.
  - refreshUser() must demote to GUEST on any failure.
  - MutationOutcome type: completed | auth_required | queued_retry.
  - Env var standard: EXPO_PUBLIC_SUPABASE_ANON_KEY (not SUPABASE_KEY).
  - One supabase client only: src/lib/supabase.ts. Delete utils/supabase.ts.
  - profiles.role is immutable from client. Enforce via RLS check policy.

## Assistant (commentary)

`2026-03-11T02:53:39.673Z`

Using `staff-mobile-engineer` for this turn because the request is a production React Native/Expo phase-gate with architectural constraints. I’m starting by loading the skill instructions and inspecting the repo state, manifest references, and current package/build setup before I run install and a dev build.

## Assistant (commentary)

`2026-03-11T02:53:57.723Z`

I’ve confirmed this is already an Expo-managed app with dependencies installed, and the canonical manifest files are present. Next I’m checking package scripts, current git state, and the Phase 4 sections in the launch docs so the install/build gate and any follow-on work line up with the actual repo.

## Assistant (commentary)

`2026-03-11T02:54:23.137Z`

The phase gate is clear: I need to validate the current tree with `npm install` and an Expo dev build before touching Phase 4. After that I’ll inspect the existing map/auth/data layers against the manifest, then either fix any preexisting drift blocking Phase 4 or start implementing the missing map/location/favorites/search surface in production-safe slices.

## Assistant (commentary)

`2026-03-11T02:54:40.928Z`

I’m moving into validation now: package resolution first, then native Expo validation. If the native build path fails because of local Android/iOS toolchain issues rather than app code, I’ll separate environment blockers from repository blockers before making changes.

## Assistant (commentary)

`2026-03-11T02:55:31.774Z`

The first hard blocker is native, not Phase 4 code: `expo run:android` fails during prebuild because [app.config.ts](/Users/T/Desktop/PeeDom/app.config.ts) references missing image assets, starting with `assets/adaptive-icon.png`. I’m inspecting the config and existing asset references now so I can fix the native build path before I touch feature code.

## Assistant (commentary)

`2026-03-11T02:56:04.309Z`

I’m fixing the native prebuild break now by creating the missing Expo asset set referenced from [app.config.ts](/Users/T/Desktop/PeeDom/app.config.ts). After that I’ll rerun `expo run:android` to see whether the next failure is environmental or actual application/runtime drift.

## Assistant (commentary)

`2026-03-11T02:57:29.731Z`

The repo-side prebuild blocker is fixed; the next failure is local toolchain: Expo can’t find an Android SDK or `adb`. I’m checking whether the SDK is installed in a non-default path so I can complete the build gate instead of treating this as a hard stop.

## Assistant (commentary)

`2026-03-11T02:58:43.217Z`

The native build gate is as far as this machine can take it right now: Expo prebuild is working, but an Android SDK is not installed or exposed in `ANDROID_HOME`, so an actual device/emulator build cannot start. I’m moving into a code audit of the map/search/favorites/location surface so I can fix repo-side gaps while keeping the environment blocker explicit.

## Assistant (commentary)

`2026-03-11T03:01:29.996Z`

The audit is surfacing real architectural drift, not just missing screens: `return-intent` is persisted to `AsyncStorage` even though it must be memory-only, the offline queue is unvalidated on load, and the map/search/favorites surface is still Phase 1 scaffold code. I’m checking the Supabase schema/migrations next so I can implement the feature layer against what actually exists instead of the aspirational manifest.

## Assistant (commentary)

`2026-03-11T03:05:01.473Z`

I have enough context to start implementation. The minimal production-safe slice is: fix the auth/queue invariants first, add the missing location/favorites/search/map infrastructure on top of the actual Supabase schema, then wire the tabs and verify with unit tests plus lint/type-check.

## Assistant (commentary)

`2026-03-11T03:07:02.204Z`

I’m adding the missing runtime packages before I wire the new screens so the code lands against the intended stack instead of building around missing dependencies. After that I’ll patch the auth/queue invariants and then write the feature modules on top.

## Assistant (commentary)

`2026-03-11T03:22:35.642Z`

I’m patching the core contracts first: shared types, validation, auth intent handling, and offline queue behavior. This is the part that will either keep the new Phase 4 features coherent or make them impossible to reason about later.

## Assistant (commentary)

`2026-03-11T03:24:33.058Z`

I’m replacing the persisted return-intent flow now. The new contract is memory-only and owned by `AuthContext`, which is what the Phase 4 favorite replay logic will depend on.

## Assistant (commentary)

`2026-03-11T03:25:54.105Z`

The auth layer had drifted since the first pass; there’s already a newer `supabase-error` and navigation safety abstraction in the tree. I’m adapting the in-memory intent change to the current auth implementation rather than clobbering those protections.

## Assistant (commentary)

`2026-03-11T03:32:10.764Z`

I’m moving into the data and query layer now: typed bathroom/favorites fetchers, filter/distance utilities, and route normalization. Once those are in place, the screen code is mostly composition rather than guesswork.

## Assistant (commentary)

`2026-03-11T03:37:15.677Z`

I’m on the presentation layer now: reusable cards, the map wrapper, the offline banner, and the bottom sheet. Once those land, the tab screen replacements are mostly wiring and state transitions.

## Assistant (commentary)

`2026-03-11T03:38:47.700Z`

I’m replacing the Phase 1 tab scaffolds now. These screens are where the corrected auth contract, location context, query hooks, and UI primitives finally come together.

## Assistant (commentary)

`2026-03-11T03:40:31.680Z`

The feature skeleton is in place. I’m running TypeScript now before I add the migration/test layer so I can fix the inevitable contract mismatches while the changes are still localized.

## Assistant (commentary)

`2026-03-11T03:41:05.640Z`

TypeScript failed on a straightforward import syntax issue in the new map wrapper. I’m correcting that first, then rerunning the compiler to surface the real contract errors underneath it.

## Assistant (commentary)

`2026-03-11T03:42:22.652Z`

The compiler is now down to Supabase typing gaps from the generated schema, not screen logic. I’m tightening those call sites with explicit casts and a safer queue payload predicate rather than expanding the whole generated type surface by hand.

## Assistant (commentary)

`2026-03-11T03:42:42.316Z`

I’ve got the app compiling. I’m adding the missing database migration and a small unit-test layer around the new pure utilities before I move to lint/Jest so the contract changes are actually verified.

## Assistant (commentary)

`2026-03-11T03:44:03.532Z`

TypeScript is clean. I’m running lint, Jest, and Expo dependency checks now; after that I’ll do one more Android build attempt so the final status clearly separates repository state from the missing local SDK.

## Assistant (commentary)

`2026-03-11T03:44:30.845Z`

The remaining repo failures are small and local: one lint issue in the new favorites hook, and the navigation helper still treats route groups as public path segments. I’m fixing those now, then rerunning lint and Jest.

## Assistant (commentary)

`2026-03-11T03:45:24.373Z`

The codebase validations are clean. I’m doing one final Android build attempt plus a worktree check so the closeout can distinguish between repository changes, generated assets, and the remaining local SDK blocker.

## Assistant (final_answer)

`2026-03-11T03:46:38.319Z`

Implemented the Phase 4 foundation and screen layer across [AuthContext.tsx](C:/Users/T/Desktop/PeeDom/src/contexts/AuthContext.tsx), [LocationContext.tsx](C:/Users/T/Desktop/PeeDom/src/contexts/LocationContext.tsx), [useBathrooms.ts](C:/Users/T/Desktop/PeeDom/src/hooks/useBathrooms.ts), [useFavorites.ts](C:/Users/T/Desktop/PeeDom/src/hooks/useFavorites.ts), [index.tsx](C:/Users/T/Desktop/PeeDom/app/(tabs)/index.tsx), [search.tsx](C:/Users/T/Desktop/PeeDom/app/(tabs)/search.tsx), and [favorites.tsx](C:/Users/T/Desktop/PeeDom/app/(tabs)/favorites.tsx). That includes in-memory guest intent replay via `requireAuth`, Zod-validated offline queue loading, `refreshUser()` demotion to `GUEST` on failure, map/location state with Zustand, favorites CRUD + replay/queueing, offline sync, and the new UI primitives in [BathroomCard.tsx](C:/Users/T/Desktop/PeeDom/src/components/BathroomCard.tsx), [MapView.tsx](C:/Users/T/Desktop/PeeDom/src/components/MapView.tsx), [BottomSheet.tsx](C:/Users/T/Desktop/PeeDom/src/components/BottomSheet.tsx), and [OfflineBanner.tsx](C:/Users/T/Desktop/PeeDom/src/components/OfflineBanner.tsx).

I also fixed the repo-side native prebuild blocker by adding the missing Expo assets under `assets/`, added the Supabase migration in [002_functions.sql](C:/Users/T/Desktop/PeeDom/supabase/migrations/002_functions.sql) for `get_bathrooms_near` plus the `profiles.role` update guard, and added tests in [bathroom-utils.test.ts](C:/Users/T/Desktop/PeeDom/__tests__/bathroom-utils.test.ts) and [queued-mutations.test.ts](C:/Users/T/Desktop/PeeDom/__tests__/queued-mutations.test.ts).

Validation is clean for `npm run type-check`, `npm run lint`, and `npm test -- --runInBand`. `npx expo run:android` is still blocked by the local machine, not the repo: Android SDK was not found at `C:\Users\T\AppData\Local\Android\Sdk` and `adb` is not on `PATH`. `npx expo install --check` also reports broader package-version drift against current Expo recommendations; I left that alone because upgrading the Expo/React Native stack would be a separate, high-risk change.

## User

`2026-03-11T13:04:47.302Z`

<environment_context>
  <shell>powershell</shell>
  <current_date>2026-03-11</current_date>
  <timezone>America/Los_Angeles</timezone>
</environment_context>

## User

`2026-03-11T13:04:47.304Z`

SYSTEM: ACTIVATE [BUILDER_PRIME_MODE]Project: Pee-Dom (bathroom-finder, iOS + Android)Repo: Tdub206/Pee-DomStack: React Native 0.76.5, Expo SDK 54, Expo Router v4, TypeScript strict, NativeWind v4, Supabase (PostgreSQL + PostGIS + Auth), TanStack Query v5, AsyncStorage.STATUS:- Phase 1/2/3: COMPLETE. type-check, lint, test all pass.- Phase 4 (map/search/favorites): NOT STARTED. Tab screens are Phase 1 scaffolds.- Pre-Phase-4 blockers: (1) npx expo install --check fails (dep drift), (2) missing packages (@sentry/react-native, @react-native-community/netinfo, @gorhom/bottom-sheet, zod, zustand), (3) placeholder assets missing (assets/icon.png, splash.png, adaptive-icon.png).THE 3 LAWS:1. Pre-Flight: Simulate full dependency graph before writing. Map every affected file. Verify every import.2. Native Purity: BANNED: div, span, localStorage, window, alert(). REQUIRED: View, Text, AsyncStorage, Alert.alert(). Auth redirects via src/lib/navigation.ts.3. Atomic: Output complete files only. No partial snippets. No "// ... rest of code".KEY CONTRACTS:- Single Supabase client: src/lib/supabase.ts. Lazy, fail-closed. Never instantiate elsewhere.- Auth: BOOTSTRAPPING > GUEST | SESSION_RECOVERY > AUTHENTICATED_USER | BUSINESS | ADMIN | SESSION_INVALID- refreshUser() MUST demote to GUEST on any failure.- Guest-intent replay: in-memory only via AuthContext.requireAuth(). Never persist to offline queue.- Offline queue: authenticated transient failures only. Zod-validated. User-scoped. Max 3 retries.- MutationOutcome: completed | auth_required | queued_retry- profiles.role immutable from client (002_functions.sql guard).- SplashScreen hides only after sessionStatus !== BOOTSTRAPPING.- Master Launch Manifest is canonical. All decisions conform to it.

## Assistant (commentary)

`2026-03-11T13:05:06.669Z`

I’m reconciling your directive against the current workspace before taking the next step. I’ll verify the repo state, dependency surface, and the actual Phase 4 status so I don’t plan off stale assumptions.

## Assistant (final_answer)

`2026-03-11T13:05:39.689Z`

Builder Prime Mode is active.

As of March 11, 2026, the workspace does not match the status block you pasted. The current repo already has the previously missing packages in [package.json](C:/Users/T/Desktop/PeeDom/package.json), the placeholder assets exist under `assets/`, and the worktree is effectively clean except for [LAUNCH_MANIFEST.md](C:/Users/T/Desktop/PeeDom/LAUNCH_MANIFEST.md).

The remaining blockers are different now:
- `npx expo install --check` still reports dependency drift against current Expo recommendations.
- `npx expo run:android` is blocked by the local machine, not the repo: no Android SDK at `C:\Users\T\AppData\Local\Android\Sdk`, and `adb` is not on `PATH`.

The next safe step is to reconcile [LAUNCH_MANIFEST.md](C:/Users/T/Desktop/PeeDom/LAUNCH_MANIFEST.md) with the actual repo state, then decide whether to spend effort on Expo/package drift or continue feature hardening under the current pinned stack.

## User

`2026-03-11T13:06:58.771Z`

okay, continue with the next safe step

## Assistant (commentary)

`2026-03-11T13:07:16.183Z`

Using `staff-mobile-engineer` again because this is still a launch-readiness and architecture reconciliation pass. I’m reading the current manifest and its local diff first so I can update only the stale sections without trampling unrelated edits in [LAUNCH_MANIFEST.md](C:/Users/T/Desktop/PeeDom/LAUNCH_MANIFEST.md).

## Assistant (commentary)

`2026-03-11T13:07:54.314Z`

The manifest is stale in exactly the areas we expected: it still says the assets and Phase 4 files are missing, and the pasted system block at the bottom is now wrong. I’m verifying the current Phase 4 surface from the repo so I can rewrite the manifest to the actual March 11, 2026 state instead of a halfway snapshot.

## Assistant (commentary)

`2026-03-11T13:08:30.448Z`

The tab surfaces and supporting modules are no longer placeholders. I’m checking a few more canonical files plus the current validation commands so the manifest can make precise claims instead of hand-wavy ones.

## Assistant (commentary)

`2026-03-11T13:09:07.172Z`

PowerShell execution policy blocked the `npm`/`npx` shims, not the project itself. I’m rerunning the checks through `npm.cmd`/`npx.cmd` so the manifest can record the real command results from this machine.

## User

`2026-03-11T13:13:33.064Z`

continue generating

## Assistant (commentary)

`2026-03-11T13:14:12.411Z`

I’m replacing the manifest wholesale now. The current file has both stale project state and encoding corruption, so a targeted edit would leave it internally inconsistent. The replacement will reflect the actual repo and command results from March 11, 2026.

## Assistant (commentary)

`2026-03-11T13:16:01.123Z`

The manifest rewrite is in place. I’m doing a quick sanity check on the file contents and worktree so I can close this step cleanly and point to the next decision instead of leaving it implicit.

## Assistant (commentary)

`2026-03-11T13:16:31.585Z`

I spotted two new worktree changes outside the manifest after the verification pass: [package.json](C:/Users/T/Desktop/PeeDom/package.json) and [package-lock.json](C:/Users/T/Desktop/PeeDom/package-lock.json). I didn’t edit those directly, so I’m checking what changed before I close out.

## Assistant (commentary)

`2026-03-11T13:17:19.882Z`

`expo install --check` dirtied [package.json](C:/Users/T/Desktop/PeeDom/package.json) in a way that is not safe to keep: it rewrote core stack versions toward a different Expo/RN ecosystem. I’m restoring the pinned versions and keeping only the legitimate `zustand` dependency that the current code actually imports.

## Assistant (commentary)

`2026-03-11T13:18:09.059Z`

The accidental core-version rewrite is cleaned up. I’m checking the manifest/package diffs one last time so I can hand back a worktree that only contains intentional state updates from this pass.

## Assistant (final_answer)

`2026-03-11T13:18:28.552Z`

I reconciled and rewrote [LAUNCH_MANIFEST.md](C:/Users/T/Desktop/PeeDom/LAUNCH_MANIFEST.md) to the actual repo state as of March 11, 2026. It now records that Phase 4 code exists in-repo, the placeholder assets are present, guest-intent replay lives in AuthContext instead of a persisted return-intent file, and the real blockers are dependency drift, missing local Android SDK/`adb`, device verification, and CI.

I also cleaned up an accidental side effect from `expo install --check`: [package.json](C:/Users/T/Desktop/PeeDom/package.json) had been rewritten toward a newer Expo ecosystem. I restored the pinned stack and left only the intentional `zustand` dependency in [package.json](C:/Users/T/Desktop/PeeDom/package.json) and [package-lock.json](C:/Users/T/Desktop/PeeDom/package-lock.json), since the current code imports it.

Current verified state:
- `npm.cmd run type-check`: pass
- `npm.cmd run lint`: pass
- `npm.cmd test -- --runInBand`: pass
- `npx.cmd expo install --check`: fail, with networking disabled and a local dependency map warning
- `npx.cmd expo run:android`: fail, because `C:\Users\T\AppData\Local\Android\Sdk` and `adb` are missing

The next safe step is [GitHub mobile CI](C:/Users/T/Desktop/PeeDom/.github/workflows), replacing the generic npm publish workflow with PR `type-check`/`lint`/`test` plus EAS build flows.
